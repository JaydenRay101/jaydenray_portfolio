# Jayden Ray Portfolio

A responsive static portfolio website for Jayden Ray — Brand Designer, Graphic Designer & Visual Identity Specialist.

## Publish on GitHub Pages

1. Create a new GitHub repository, for example `jayden-ray-portfolio`.
2. Upload `index.html`, `style.css`, `script.js`, and the `assets` folder.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select your main branch and `/ (root)`, then save.
6. GitHub will give you a public website address.

## Adding your real project images

Put your project images inside `assets/` and replace the sample `.image-one`, `.image-two`, and `.image-three` blocks in `style.css` with `background-image: url("assets/your-image.jpg");`.

Replace the sample project names and descriptions in `index.html` with your actual work.
